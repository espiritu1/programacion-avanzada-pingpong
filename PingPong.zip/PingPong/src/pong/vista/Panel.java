/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pong.vista;

//Declaracion de todos los import necesarios para que funcione el programa
import pong.vista.Pelota;
import pong.modelo.Puntos;
import pong.vista.Raqueta;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import javax.swing.JPanel;

/**
 *
 * @author inqui
 */

//Se crea la clase extendiendo la funcion de JPanel y a la vez implementa el uso de hilos
public class Panel extends JPanel implements Runnable {
    //Se declaran variables que se usaran durante el desarrollo de la aplicacion
    public static final int juegoAncho = 1300;
    public static final int juegoAlto = 700;
    public static final Dimension SCREEN_SIZE = new Dimension(juegoAncho,juegoAlto);
    public static final int diamtroPelota = 20;
    public static final int raquetaAncho= 25;
    public static final int raquetaAlto = 100;
    Thread hiloDelJuego; //Se crea un objeto de la clase hilo
    Image imagen; //Se crea un objeto de la clase Image
    Graphics graficos; //Objeto de clase graficos
    Random random; //Objeto de Random
    Raqueta raqueta1; //Se crea un objeto de la clase raqueta creada previamente
    Raqueta raqueta2; //Se crea otro objeto de la clase raqueta creada previamente
    Pelota pelota; //Se crea un objeto de la clase pelota
    Puntos puntos; //Objeto de la clase puntos creada previamente
	
    public Panel(){//Se inicializan los valores que posee el constructor
	Raquetas();
	Pelota();
	puntos = new Puntos(juegoAncho,juegoAlto);
	this.setFocusable(true);
	this.addKeyListener((KeyListener) new AL());
	this.setPreferredSize(SCREEN_SIZE);
	hiloDelJuego = new Thread(this);
	hiloDelJuego.start();
    }
	
	public void Pelota() { //Se inicializa el objeto declarado previamente
		random = new Random();
		pelota = new Pelota((juegoAncho/2)-(diamtroPelota/2),random.nextInt(juegoAlto-diamtroPelota),diamtroPelota,diamtroPelota);
	}
	public void Raquetas() {//Se inicializa el objeto de la clase raquetas cpn una posicion determinada
		raqueta1 = new Raqueta(0,(juegoAlto/2)-(raquetaAlto/2),raquetaAncho,raquetaAlto,1);
		raqueta2 = new Raqueta(juegoAncho-raquetaAncho,(juegoAlto/2)-(raquetaAlto/2),raquetaAncho,raquetaAlto,2);
	}
	public void paint(Graphics g) { // Con este metodo se dibuja en pantalla 
		imagen = createImage(getWidth(),getHeight());
		graficos = imagen.getGraphics();
		draw(graficos);
		g.drawImage(imagen,0,0,this);
	}
	public void draw(Graphics g) { //"Dibuja" en pantalla las raquetas, pelotas y el marcador
		raqueta1.dibujar(g);
		raqueta2.dibujar(g);
		pelota.draw(g);
		puntos.draw(g);
                Toolkit.getDefaultToolkit().sync(); 

	}
	public void mover() {//Permite el movimiento de las raquetas
		raqueta1.mover();
		raqueta2.mover();
		pelota.move();
	}
	public void Colicion() { //Clase encargada de gestionar el movimiento de la pelota tras impactar con la paleta
		
		if(pelota.y <=0) {
			pelota.YDireccion(-pelota.yVelocidad);
		}
		if(pelota.y >= juegoAlto-diamtroPelota) {
			pelota.YDireccion(-pelota.yVelocidad);
		}

		if(pelota.intersects(raqueta1)) {
			pelota.xVelocidad = Math.abs(pelota.xVelocidad);
			pelota.xVelocidad++; 
			if(pelota.yVelocidad>0)
				pelota.yVelocidad++; 
			else
				pelota.yVelocidad--;
			pelota.XDireccion(pelota.xVelocidad);
			pelota.YDireccion(pelota.yVelocidad);
		}
		if(pelota.intersects(raqueta2)) {
			pelota.xVelocidad = Math.abs(pelota.xVelocidad);
			pelota.xVelocidad++; 
			if(pelota.yVelocidad>0)
				pelota.yVelocidad++; 
			else
				pelota.yVelocidad--;
			pelota.XDireccion(-pelota.xVelocidad);
			pelota.YDireccion(pelota.yVelocidad);
		}
		//esto detiene a la raqueta
		if(raqueta1.y<=0)
			raqueta1.y=0;
		if(raqueta1.y >= (juegoAlto-raquetaAlto))
			raqueta1.y = juegoAlto-raquetaAlto;
		if(raqueta2.y<=0)
			raqueta2.y=0;
		if(raqueta2.y >= (juegoAlto-raquetaAlto))
			raqueta2.y = juegoAlto-raquetaAlto;
		
                //Apartado en el cual se calcula el puntaje del jugador
		if(pelota.x <=0) {
			puntos.jugador2++;
			Raquetas();
			Pelota();
			System.out.println("Player 2: "+puntos.jugador2);
		}
		if(pelota.x >= juegoAncho-diamtroPelota) {
			puntos.jugador1++;
			Raquetas();
			Pelota();
			System.out.println("Player 1: "+puntos.jugador1);
		}
	}
	public void run() {
		//ciclo
		long lastTime = System.nanoTime();
		double amountOfTicks =60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		while(true) {
			long now = System.nanoTime();
			delta += (now -lastTime)/ns;
			lastTime = now;
			if(delta >=1) {
				mover();
				Colicion();
				repaint();
				delta--;
			}
		}
	}
	public class AL extends KeyAdapter{
		public void keyPressed(KeyEvent e) {
			raqueta1.keyPressed(e);
			raqueta2.keyPressed(e);
		}
		public void keyReleased(KeyEvent e) {
			raqueta1.keyReleased(e);
			raqueta2.keyReleased(e);
		}
	}
}
