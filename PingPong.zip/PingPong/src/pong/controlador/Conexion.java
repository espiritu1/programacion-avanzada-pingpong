/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pong.controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author inqui
 */
public class Conexion {
    //En este apartado se daran los datos necesarios para realizar la conexion a la BD
    Connection con = null;
    String usuario = "root";
    String pass = "";
    String url = "jdbc.mysql://localhost:3306/pongp";
    Statement stat;
    ResultSet rs;
    
    //
    public Connection conexion(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, usuario, pass); 
            JOptionPane.showMessageDialog(null, "Conexion lograda");
            
            stat = con.createStatement();
            stat.executeQuery("INSERT INTO usuario(nickname, puntaje, frase) VALUES('Perrito', 0, 'Siempre gano')");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Conexion fallida" + e.getMessage());
        }
        
    
    return con;
    }
}
