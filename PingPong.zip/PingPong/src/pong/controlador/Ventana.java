package pong.controlador;

import pong.vista.Panel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;




public class Ventana extends JFrame{

	Panel panel;
	
	
	public Ventana(String pong, int x, int y, int ancho, int alto){
		super(pong);

		this.setBounds(x,y,ancho, alto);
	    this.setLayout(new BorderLayout());

		panel = new Panel();
	
		
		
		this.add(panel ,BorderLayout.CENTER);

		this.setResizable(false);
		this.setBackground(Color.black);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.setVisible(true);

	}
}